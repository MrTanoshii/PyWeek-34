from pathlib import Path


class WORLD:
    BASEPATH_MAPS = Path("src/world/maps")
