class DEBUG:
    ALL = False
    MOUSE = ALL or False
    MAP = ALL or False
    TOWER = ALL or False
    BULLET = ALL or False
