from pathlib import Path


class EMEMY:
    BASEPATH = Path("src/enemy/sprites")
