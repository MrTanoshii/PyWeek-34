from .gold import *
from .research import *
from .resource import *
from .lives import *
from .score import *
