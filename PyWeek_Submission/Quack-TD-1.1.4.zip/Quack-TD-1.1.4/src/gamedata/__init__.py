from .gamedata import *
