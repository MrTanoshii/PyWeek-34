class SETTINGS:
    # Window Config
    CURSOR_VISIBLE = True
    CENTER_WINDOW = True
    FULLSCREEN = False
    FULLSCREEN_WINDOWED = False
    RESIZEABLE = False  # good luck making it responsive
    SCREEN_WIDTH = 1280
    SCREEN_HEIGHT = 720
    SCREEN_TITLE = "Quack TD by Turtle Duck lTD."

    GLOBAL_SCALE = 1
