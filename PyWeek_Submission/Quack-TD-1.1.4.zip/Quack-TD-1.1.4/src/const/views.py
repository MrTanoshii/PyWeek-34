import arcade


class VIEWS:

    # Map view
    FONT_SIZE = 18
    BACKGROUND_COLOR = arcade.color.DIM_GRAY

    # Game End View?
